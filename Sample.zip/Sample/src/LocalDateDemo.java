import java.time.LocalDate;


public class LocalDate{
	public static void main(String[] args) {
		LocalDate currentDate = LocalDate.now();
		System.out.println("currentdate:"+ currentdate);
}
}