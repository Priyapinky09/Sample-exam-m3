


public class LocalDate{
	public static void main(String[] args) {
		LocalDate currentDate = LocalDate.now();
		System.out.print