
	public class TestDemo 
	{
	 @Test  
	 public void tryAssert1()
	 {
	assertEquals(30,Integer.parseInt("30"));
	 }
	 @Test  
	 public void tryAssert2()
	 {
	  assertEquals("Five", "FivE");
	 }
	 @Test  
	 public void tryAssert3()
	 {
	  assertEquals(new Date().getyear(), new GregorianCalendar().get(Calendar.YEAR));
	 }
	}
